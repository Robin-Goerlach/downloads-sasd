Companion files placeholder for SASD Engineering Guide.
