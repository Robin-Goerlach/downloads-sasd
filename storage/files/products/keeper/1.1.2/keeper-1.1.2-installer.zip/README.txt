Keeper 1.1.2 placeholder installer package.
