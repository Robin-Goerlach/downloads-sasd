SASD LogView 3.5 placeholder package.
