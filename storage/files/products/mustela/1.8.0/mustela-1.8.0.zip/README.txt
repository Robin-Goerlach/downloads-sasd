Archived Mustela 1.8.0 placeholder package.
